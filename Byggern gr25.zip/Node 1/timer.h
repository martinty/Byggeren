#ifndef TIMER_H_
#define TIMER_H_

void timer_init();
void timer_start();
int timer_stop();
int timer_read();

#endif /* TIMER_H_ */