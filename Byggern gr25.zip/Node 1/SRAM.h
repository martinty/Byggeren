#ifndef SRAM_H_
#define SRAM_H_

void SRAM_init(void);
void SRAM_test(void);

#endif /* SRAM_H_ */