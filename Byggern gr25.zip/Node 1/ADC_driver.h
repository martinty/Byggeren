#ifndef ADC_DRIVER_H_
#define ADC_DRIVER_H_

void ADC_init(void);
int ADC_getData(int channel);

#endif /* ADC_DRIVER_H_ */