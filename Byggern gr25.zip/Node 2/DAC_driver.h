#ifndef DAC_DRIVER_H_
#define DAC_DRIVER_H_

void DAC_init();
void DAC_write(int value);

#endif /* DAC_DRIVER_H_ */