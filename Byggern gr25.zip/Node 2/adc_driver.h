#ifndef ADC_DRIVER_H_
#define ADC_DRIVER_H_

void adc_init();
uint8_t adc_read();

#endif /* ADC_DRIVER_H_ */