#ifndef PWM_H_
#define PWM_H_

void pwm_init(double periode_ms);
void pwm_dutyCycle(float dutyCycle);

#endif /* PWM_H_ */