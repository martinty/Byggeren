#ifndef SOLENOID_H_
#define SOLENOID_H_

void solenoid_init();
void solenoid();

#endif /* SOLENOID_H_ */