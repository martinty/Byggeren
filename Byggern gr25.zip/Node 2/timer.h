#ifndef TIMER_H_
#define TIMER_H_

void timer_init(int ms);

#endif /* TIMER_H_ */